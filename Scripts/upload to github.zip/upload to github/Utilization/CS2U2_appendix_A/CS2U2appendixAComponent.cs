﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

// In order to load the result of this wizard, you will also need to
// add the output bin/ folder of this project to the list of loaded
// folder in Grasshopper.
// You can use the _GrasshopperDeveloperSettings Rhino command for that.

namespace CS2U2_appendix_A
{
    public class CS2U2appendixAComponent : GH_Component
    {
        /// <summary>
        /// Each implementation of GH_Component must provide a public 
        /// constructor without any arguments.
        /// Category represents the Tab in which the component will appear, 
        /// Subcategory the panel. If you use non-existing tab or panel names, 
        /// new tabs/panels will automatically be created.
        /// </summary>
        public CS2U2appendixAComponent()
          : base("CS2U2_appendix_A", "CS2U2",
              "Description",
              "Master's Thesis", "Surrogate models")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddIntegerParameter("Node number", "n", "Number of the node we want to investigate", GH_ParamAccess.item);
            pManager.AddNumberParameter("z-comp. of cPt5", "cPt5_z", "z component of control point 5", GH_ParamAccess.item);
            pManager.AddNumberParameter("z-comp. of cPt6", "cPt6_z", "z component of control point 6", GH_ParamAccess.item);
            pManager.AddNumberParameter("z-comp. of cPt9", "cPt9_z", "z component of control point 9", GH_ParamAccess.item);
            pManager.AddNumberParameter("z-comp. of cPt10", "cPt10_z", "z component of control point 10", GH_ParamAccess.item);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Utilization", "Util", "Utilization of element", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            int elem = 0;
            double cPt5_z = 0;
            double cPt6_z = 0;
            double cPt9_z = 0;
            double cPt10_z = 0;

            // Check if the user provides input
            if (!DA.GetData(0, ref elem)) return;
            if (!DA.GetData(1, ref cPt5_z)) return;
            if (!DA.GetData(2, ref cPt6_z)) return;
            if (!DA.GetData(3, ref cPt9_z)) return;
            if (!DA.GetData(4, ref cPt10_z)) return;

            //Cast inputs to floats. ML model needs input in form of floats
            float f_elem = (float)elem;
            float f_cPt5_z = (float)cPt5_z;
            float f_cPt6_z = (float)cPt6_z;
            float f_cPt9_z = (float)cPt9_z;
            float f_cPt10_z = (float)cPt10_z;

            ModelInput sampleData = new ModelInput()
            {
                Col0 = f_elem,
                Col1 = f_cPt5_z,
                Col2 = f_cPt6_z,
                Col3 = f_cPt9_z,
                Col4 = f_cPt10_z,
            };

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                // You can add image files to your project resources and access them like this:
                //return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Each component must have a unique Guid to identify it. 
        /// It is vital this Guid doesn't change otherwise old ghx files 
        /// that use the old ID will partially fail during loading.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("e1b5f427-760a-4fa1-80e7-350555655cb8"); }
        }
    }
}
